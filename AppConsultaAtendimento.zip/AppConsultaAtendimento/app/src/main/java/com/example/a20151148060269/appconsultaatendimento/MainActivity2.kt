package com.example.a20151148060269.appconsultaatendimento

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.SearchView
import kotlinx.android.synthetic.main.activity_main2.*

import android.support.v7.widget.Toolbar
import android.widget.Toast
import android.widget.AdapterView
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView




 class MainActivity2 : AppCompatActivity() {




     override fun onCreate(savedInstanceState: Bundle?) {
         super.onCreate(savedInstanceState)
         setContentView(R.layout.activity_main2)

         val argumentos: Bundle = intent.extras

         val usuario: String = argumentos.getString("usuario")
         val numerosus: String = argumentos.getString("numerosus")

         textView_usuario.text = "Bem vindo, $usuario!!"
         textView_numero.text = "Número do SUS: $numerosus"

         //REFERENCE MATERIALSEARCHBAR AND LISTVIEW
         val lv = findViewById(R.id.mListView) as ListView
         val searchBar = findViewById(R.id.searchBar) as SearchView
         searchBar.setHint("Search..")
         searchBar.setSpeechMode(true)

         var galaxies = arrayOf("Sombrero", "Cartwheel", "Pinwheel", "StarBust", "Whirlpool", "Ring Nebular", "Own Nebular", "Centaurus A", "Virgo Stellar Stream", "Canis Majos Overdensity", "Mayall's Object", "Leo", "Milky Way", "IC 1011", "Messier 81", "Andromeda", "Messier 87")

         //ADAPTER
         val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, galaxies)
         lv.setAdapter(adapter)

         //SEARCHBAR TEXT CHANGE LISTENER
         searchBar.addTextChangeListener(object : TextWatcher {
             override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {

             }

             override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
                 //SEARCH FILTER
                 adapter.getFilter().filter(charSequence)
             }

             override fun afterTextChanged(editable: Editable) {

             }
         })

         //LISTVIEW ITEM CLICKED
         lv.setOnItemClickListener(object : AdapterView.OnItemClickListener {
             override fun onItemClick(adapterView: AdapterView<*>, view: View, i: Int, l: Long) {
                 Toast.makeText(this@MainActivity2, adapter.getItem(i)!!.toString(), Toast.LENGTH_SHORT).show()
             }
         })

         //end

     }





 }
